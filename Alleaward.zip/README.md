# alleaward.com
My portfolio/resume website.

## Skills

### HTML
>I used HTML as the markup.

### CSS
>CSS was used for styling, i used the SASS preprocessor and the Ionicons library.

### JavaScript
>I used JavaScript for interactivity and animations.

### Vue JS
>I used Vue to create an interactive portfolio section with a sortable list. Vue Router was used for navigation.

### PHP
>PHP was used to process the form data and send it to my email.

## Copyright
>Anyone is free to use/improve/critique this code.