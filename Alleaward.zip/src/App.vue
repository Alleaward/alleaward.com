<template>
  <div id="app">
    <!-- <h1>TEST</h1> -->
    <router-view></router-view>
    <!-- <home-testing></home-testing> -->
  </div>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<style lang="scss">

</style>
