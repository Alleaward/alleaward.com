<template>
<div id="resume">
  <section id="details">
    <h1>Allea Ward – Full Stack Web Engineer</h1>
    <p><span>Location:</span> Pimpama, Gold Coast</p>
    <p><span>Phone:</span> +61490324716</p>
    <p><span>Age:</span> 23</p>
    <p><span>Email:</span> Allea_ward@hotmail.com</p>
    <p><span>GitHub:</span> www.github.com/alleaward 	</p>
    <p><span>LinkedIn:</span> www.linkedin.com/alleaward</p>
    <p><span>Current Driver's license:</span> Yes. </p>
    <p><span>Remote Work:</span> I am happy to work remotely. </p>
    <!-- <p>Blog: <a href="blog.alleaward.com">My Blog</a> </p> -->

    <h2>Objective</h2>
    <p>My objective is to create software that is pixel perfect and as computationally efficient as possible, 
      I am looking forward to furthering my career and becoming a master of my art. 
      <br>
      <br>I have been extremely passionate about IT, the web, programming and digital media my entire life, ever since I received my first Gameboy,
      I had no doubt I would one day be creating digital media professionally. This lifelong passion for all things digital has translated
      into a broad range of knowledge on subjects ranging from 3D modelling, graphic design, animation and game design to computer science, programming, and web development. 
      <br>
      <br>My primary strength is that I am a quick learner, I have knowledge of a wide range of skills, and each skill allows me to more quickly contextualize and learn future skills faster. I am actively pursuing technical, personal and professional development.
    </p>
    <p>
      <i class="ion-android-star"></i> 
      &nbsp; = &nbsp; I have some exposure or currently learning.<br>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      &nbsp; = &nbsp; I understand the fundamentals.<br>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      &nbsp; = &nbsp; I have a working knowledge.<br>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      &nbsp; = &nbsp; I have used it in several projects.<br>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      <i class="ion-android-star"></i>
      &nbsp; = &nbsp; I can use it proficiently from memory.
    </p>
  </section>

  <div id="social-banner">
    <ul id="social-link">
      <li class="github"><a href="https://github.com/Alleaward"><i class="ion-social-github"></i></a></li>
      <li class="linkedin"><a href="https://www.linkedin.com/in/alleaward/"><i class="ion-social-linkedin"></i></a></li>
      <!-- <li class="youtube"><a href=""><i class="ion-social-youtube"></i></a></li> -->
    </ul>
  </div>

  <!-- <h1>A TIMELINE? (2011 Learned JS -> 2012 LEarned C#)</h1> -->

  <section id="skills">
    <section class="skillAccordian" id="frontend">    
      <section id="languages" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">Languages
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
            </p>
            <ul class="skillDesc">
              Over the past decade, I have become familiar with several languages, and I have had exposure to many more.<br>
              <li>
                <p>HTML5</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                </span>
              </li>
              <li>
                <p>CSS3</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                </span>
              </li>
              <li>
                <p>JavaScript</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>PHP</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Python</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>C</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>C#</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Java</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>
    </section>

    <h2>Front-End</h2>
    <section class="skillAccordian" id="frontend">
      <section id="html" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
          <p class="skillHeading">HTML
            <i class="ion-android-star"></i>
            <i class="ion-android-star"></i>
            <i class="ion-android-star"></i>
            <i class="ion-android-star"></i>
            <i class="ion-android-star"></i>
          </p>
          <ul class="skillDesc">
            <p>
              I have an advanced grasp of HTML up to and including <strong>HTML5</strong> with most of its functionality committed to memory. 
              I know how to make a properly formed and validated HTML page.
            </p>
          </ul>
          </div>

        </div>
      </section>
        
      <section id="css" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">CSS
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
            </p>
            <ul class="skillDesc">
              <p>
                I am <strong>very</strong> familiar with CSS selectors and properties. I can make just about anything from a mockup using CSS and HTML, 
                including most interactivity with new features brought by CSS3. I have used <strong>frameworks</strong> such as <strong>Bootstrap, Bulma and MaterialiseCSS,</strong>
                but I now usually just make my websites responsive/interactive with vanilla CSS using a combination of Flexbox, Grid, Transitions, 
                Transforms and Psuedo-Selectors. I mainly use the <strong>SASS preprocessor</strong>.
              </p>
              <br>
              <br>
              <li>
                <p>Animations</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Transitions</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>SASS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Bootstrap</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>MaterializeCSS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Bulma</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section id="javascript" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">JavaScript
              <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
              </span>
            </p>
            <ul class="skillDesc">
              <p>
                I have been using JavaScript for several years now and have grown quite competent in it, 
                While I have <b>strong</b> skills with <b>vanilla JavaScript</b>, I used to use <b>jQuery</b> for convenience but I have transitioned into <b>VueJS</b> instead. 
                I understand most of the concepts you would expect of a JavaScript developer, including <b>the DOM, JSON, AJAX, 
                API’s</b> as well as a thorough understanding of the new features brought with <b>ES6</b> and a working understanding of <b>NodeJS</b>.<br>
              </p>
              <li>
                <p>Vanilla JS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>ES6</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>VueJS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>jQuery</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>AJAX</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>JSON</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>NodeJS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Webpack</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>NPM</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>React</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <!-- <li>
                <p>Angular</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li> -->

            </ul>
          </div>
        </div>
      </section>
    </section>

    <h2>Back-End</h2>

    <section class="skillAccordian" id="backend"> 
      <section id="php" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">PHP
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star-outline"></i>
            </p>
            <ul class="skillDesc">
              <p>
                PHP is one of the first languages I learnt years ago, I have used PHP to build many projects ranging from simple calculators to 
                websites with <a href="http://phpstore.wardwebdevelopment.com/">persistent shopping carts</a> and <a href="https://fitnessapp.wardwebdevelopment.com/">accounts</a>.<br>
              </p>
              <!-- <li>
                <p>Laravel</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li> -->
            </ul>
          </div>
        </div>
      </section>

      <section id="mysql" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">Databases
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star-outline"></i>
              <i class="ion-android-star-outline"></i>
            </p>
            <ul class="skillDesc">
              <p>
                I have used MySQL to store user accounts and data, for example, a <a href="https://fitnessapp.wardwebdevelopment.com/">Dietary Calculator</a> that stores user data server side.
              </p>
              <li>
                <p>MySQL</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>MongoDB</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section id="nodejs" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">NodeJS
                <i class="ion-android-star"></i>
                <i class="ion-android-star"></i>
                <i class="ion-android-star"></i>
                <i class="ion-android-star-outline"></i>
                <i class="ion-android-star-outline"></i>
            </p>
            <ul class="skillDesc">
              <p>
                I relatively recently began learning <b>Node.js</b>. I have built several projects using it and look forward to learning more.
              </p>
              <li>
                <p>Vue</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Vue Router</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>NPM</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>ExpressJS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section id="windows" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">Windows
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
            </p>
            <ul class="skillDesc">
              <p>
                Windows has been my daily driver since I was a child. 
                I have very strong skills using Windows, and I can <b>intuitively</b> solve problems with it using very little help.
              </p>
              <li>
                <p>Apache</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Nginx</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>IIS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>NodeJS</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      <section id="linux" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">Linux
              <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star-half"></i>
              <i class="ion-android-star-outline"></i>
              <i class="ion-android-star-outline"></i>
            </p>
            <ul class="skillDesc">
              <p>
                Throughout my education in web development, I have used Linux many times, 
                I am growing <b>competent and confident</b> in its use and can use it for everything I need. I have begun the process of migrating to Linux and would like to eventually move to it entirely.
              </p>
              <li>
                <p>Apache</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
              <li>
                <p>Nginx</p>
                <span class="starRating">
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star"></i>
                  <i class="ion-android-star-outline"></i>
                </span>
              </li>
            </ul>          
          </div>
        </div>
      </section>

      <section id="tools" class="skillSection">
        <div class="skillInner">
          <div class="skillInfo">
            <p class="skillHeading">Tools / Misc
              <!-- <i class="ion-android-star"></i>
              <i class="ion-android-star"></i>
              <i class="ion-android-star-half"></i>
              <i class="ion-android-star-outline"></i>
              <i class="ion-android-star-outline"></i> -->
            </p>
            <ul class="skillDesc">
              <li>
                <p>Expert at Googling</p>
              </li>
              <li>
                <p>cPanel</p>
              </li>
              <li>
                <p>AWS</p>
              </li>
              <li>
                <p>SSH</p>
              </li>
              <li>
                <p>FTP</p>
              </li>
              <li>
                <p>Bash / Command Line / Terminal</p>
              </li>
              <li>
                <p>GitHub CLI &amp; App</p>
              </li>
              <li>
                <p>VS Code / Visual Studio</p>
              </li>
              <li>
                <p>Adobe Creative Suite</p>
              </li>
              <li>
                <p>Responsive Design</p>
              </li>
              <li>
                <p>Chrome / Firefox</p>
              </li>
              <li>
                <p>SSL</p>
              </li>
            </ul>          
          </div>
        </div>
      </section>
    </section>

  </section>

  <section id="education">
      <h2>Education</h2> 
      <span>Macquarie - Bachelor of Arts (Philosophy and Politics)</span> <br>
      2016 - Ongoing | Bachelor of Arts, Majoring in Philosophy and Politics.<br>
      <br>
      <span class="heading3">Relevant Results</span>
      <ul>
        <li class="heading3">How philosophy helps with programming.</li>
        <ul>
          <li> - Formal Logic</li>
          <li> - Critical Thinking</li>
          <li> - Ability to think in an abstract manner</li>
          <li> - Defining problems and solutions</li>
          <li> - Detecting fallacious reasoning</li>
          <li> - Philosophy and computer science have many overlapping concepts</li>
        </ul>
      </ul>
      <hr>
      <br>
      <span>RMIT - Bachelor of Information Technology</span> <br>
      2014 - Ongoing | Bachelor of Information of Technology. <br>
      <br>
      <span class="heading3">Relevant Results</span>
      <ul>
        <li class="heading3">Programming Fundamentals</li>
        <ul>
          <li> - Primitives</li>
          <li> - Data Structures</li>
          <li> - Operators, Expressions, Statements, Blocks and Control Flow</li>
          <li> - Algorithms</li>
          <li> - Memory Management</li>
          <li> - Design Patterns (OOP mainly)</li>
          <li> - Good programming style based within established standards, practices and guidelines</li>
          <li> - Debugging</li>
          <li> - Usability, Accessibility and Internationalization</li>
        </ul>
        <li class="heading3">Experience with several langauges</li>
        <ul>
          <li> - C</li>
          <li> - Java</li>
          <li> - Python</li>
          <li> - SQL</li>
          <li> - JavaScript</li>
          <li> - PHP</li>
          <li> - HTML/CSS</li>
        </ul>
      </ul>
      <hr>
      <br>
      <span>Goldcoast Tafe, Foxwell Rd.</span> <br>
      2014 | Diploma of Interactive Digital Media <br>
      <br>
      <span class="heading3">Relevant Results</span>
      <ul>
        <li> - A broad understanding of how the web works, everything between the client and the server. </li>
        <li> - Building websites using the LAMP stack</li>
        <li> - UI/UX	</li>
        <li> - Project Management</li>
        <li> - Flash Animation</li>
        <li> - Game Design</li>
        <li> - Managing digital assets</li>
        <li> - Creating storyboards</li>
        <li> - OH&amp;S</li>
      </ul>
      <hr>
      <br>
  </section>  

  <div class="buttonWrap">
    <button id="portfolioButton"  ><a class="button" @click="$router.push({path: '/portfolio'})">Portfolio</a></button>
  </div>

</div>

</template>

<script>
export default {
  name: 'resume',
  data () {
    return {
      msg: 'Welcome to Your Vue.js resume'
    }
  }
}
</script>

<style lang="scss">
body{
  margin: 0;
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  font-family: 'Ubuntu', sans-serif;
}
#resume {
  // max-width: 760px;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
  background-image: url("../assets/img/creampaper.png");
  padding-top: 50px;
  padding-bottom: 200px;
  // text-align: left;
  justify-items: center;
  display: flex;
  flex-flow: row wrap;
  font-size: 25px;
  span{
    font-weight: bold;
  }
  h1, h2{
    text-align: center;
  }
  h2{
    margin: 20px 0;
  }

}

//SOCIAL BANNER-----SOCIAL BANNER-----SOCIAL BANNER-----SOCIAL BANNER-----SOCIAL BANNER-----SOCIAL BANNER
#social-banner {
  // background-color: #4484CE;
  background-color: rgb(145, 137, 110);
  width: 90px;
  height: auto;
  position: fixed;
  right: 0;
  top: 30px;
  z-index: 999;
  border-radius: 30px 0px 0px 30px;
  #social-link {
    list-style: none;
    display: flex;
    flex-flow: column wrap;
    justify-content: space-around;
    padding-left: 0;
    max-width: 760px;
    // padding: 10px 0;
  }
  #social-link li {
    margin: 10px auto;
    text-align: center;
    font-size: 30px;
    line-height: 60px;
    height: 60px;
    width: 60px;
    background-color: white;
    border-radius: 50%;
  }
  #social-link li a {
    display: block;
    color: black;
    &:hover{
      color: #fff;
    }
  }
  #social-link .github:hover {
    background-color: #5245AC;
    transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    -webkit-transition: all 0.3s ease-in-out;
  }
  #social-link .linkedin:hover {
    background-color: #0077B5;
    transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    -webkit-transition: all 0.3s ease-in-out;
  }
  #social-link .youtube:hover {
    background-color: #FF0000;
    transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    -webkit-transition: all 0.3s ease-in-out;
  }
}

//DETAILS-----DETAILS-----DETAILS-----DETAILS-----DETAILS-----DETAILS-----DETAILS-----DETAILS-----DETAILS
#details{
  width: 800px;
  margin: auto;
  // padding: 0 30px;
  h1{
    position: static;
  }
  ul{
    padding: 0;
    margin: 0;
  }
  li{
    padding: none;
    list-style: none;
  }
}
//SKILLS-----SKILLS-----SKILLS-----SKILLS-----SKILLS-----SKILLS-----SKILLS-----SKILLS-----SKILLS
#skills{
  width: 100%;
  margin: auto;
  ul{
    padding: 0;
    margin: 0;
  }
  li{
    padding: none;
    list-style: none;
  }
  .skillSection{
    // flex-grow: 1;
    // flex-basis: 12.5%;
    width: 100%;
    max-height: 100px;
    min-height: 100px;
    transform: scaleY(1);
    text-align: center;
    color: transparent;
    transition: max-height 3s ease-in-out;
    -moz-transition:  max-height 3s ease-in-out;
    -webkit-transition: max-height 3s ease-in-out;  
    transition:all 0.4s ease-in-out 0.4s;
    -moz-transition:all 0.4s ease-in-out 0.4s;
    -webkit-transition:all 0.4s ease-in-out 0.4s;   
    overflow: hidden;
    a{
      color: transparent;
    }
    &:hover, &:active, &:focus{
      // flex-basis: 100%;
      // width: 50%;
      max-height: 1000px;
      transform: scaleY(1);
      .skillInner{
        background-color: rgba(233, 233, 233, 0.6);
      }
      .skillDesc{
        p{
          line-height: 1.5em;
          a{
            transition:all ease-in-out 0.4s;
            -moz-transition:all ease-in-out 0.4s;
            -webkit-transition:all ease-in-out 0.4s; 
            font-weight: bold;
            color: blue;
            text-decoration: none;
            &:hover{
              color: green;
            }
          }
        }
        li{
          // border-bottom: 2px solid black;
          background: linear-gradient(to right, rgba(255,0,0,0) 0%, 
                                      rgba(255,255,255,.6) 5%,
                                      rgba(255,255,255,.6) 50%, 
                                      rgba(255,255,255,.6) 95%, 
                                      rgba(255,0,0,0) 100%);
        }
      }
    }
    .skillHeading{
      margin-top: 20px;
      text-align: center;
      font-size: 2rem;
      width: 100%;
      color: black;
      background: linear-gradient(to right, 
                                        rgba(255,0,0,0) 30%, 
                                        rgba(255,255,255,.9) 40%, 
                                        rgba(255,255,255,.9) 60%, 
                                        rgba(255,0,0,0) 70%);
    i{
      color: gold;
      -webkit-text-stroke: 2px black;
    }
    }
    .skillHeading2{
      width: 100%;
      font-size: 150%;
      margin-bottom: 20px;
    }
    .skillDesc{
      margin: 20px;
      display: flex;
      flex-flow: row wrap;
      justify-content: flex-start;
      padding: 0 20px;
      li{
        box-sizing: border-box;
        width: 47.5%;
        padding: 5px 5% 5px 5%;
        margin: 10px 0 0 0;
        p{
          float: left;
        }
        .starRating{
          float: right;
        }
      }
    }
    p{
      margin: 0;
    }
    img{
      width: 50px;
    }
    .skillInner{
      display: flex;
      flex-flow: row wrap;
      height: 100%;
      // border: 2px red solid;
      // padding: 20px;
      // width: 760px;
      margin: auto;
      background-size: cover;
      transition:all 0.4s ease-in-out;
      -moz-transition:all 0.4s ease-in-out;
      -webkit-transition:all 0.4s ease-in-out;  
      .skillInfo{
        max-width: 760px;
        margin: 20px auto;
        // border: 2px yellow solid;
        width: 100%;
      }
      .skillImg{
        text-align: center;
        margin: auto;
        // width: 20%;
        width: auto;
        // height: auto;
        height: 200px;
      }
    }
  }

  .skillAccordian{
    display: flex;
    flex-flow: row wrap;
    width: 100%;
  }
  #languages{
    background: url('../assets/img/languages.png') no-repeat center center;
    background-size: contain;
    background-color: #D62828;
    // width: 30%;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #html{
    background: url('../assets/img/html.png') no-repeat center center;
    background-size: contain;
    background-color: #f5672a;
    // width: 30%;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #css{
    background: url('../assets/img/css.png') no-repeat center center;
    background-size: contain;
    background-color: #29a8dd;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #javascript{
    background: url('../assets/img/javascript.png') no-repeat center center;
    background-size: contain;
    background-color: #F0DB4F;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #php{
    background: url('../assets/img/php.png') no-repeat center center;
    background-size: contain;
    background-color: #8993BE;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #mysql{
    background: url('../assets/img/mysql.png') no-repeat center center;
    background-size: contain;
    background-color: #E38D1A;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #nodejs{
    background: url('../assets/img/nodejs.png') no-repeat center center;
    background-size: contain;
    background-color: #7EB341;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #linux{
    background: url('../assets/img/linux.png') no-repeat center center;
    background-size: contain;
    background-color: #404040;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #tools{
    background: url('../assets/img/tools.png') no-repeat center center;
    background-size: contain;
    background-color: #FCBF49;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
  #windows{
    background: url('../assets/img/windows.png') no-repeat center center;
    background-size: contain;
    background-color: #0077DB;
    &:hover{
      background-position: 90% 50%;
      color: black;
    }
  }
}

//education-----education-----education-----education-----education-----education-----education-----education
#education{
  // padding-top: 50px;
  width: 760px;
  padding: 0px 50px;
  margin: auto;
  .heading3{
    margin: 10px 0;
    font-weight: bold;
  }
  ul{
    float: none;
    display: block;
    padding: 0 0 0 10px;
  }
  li{
    display: block;
    list-style-type: disc;
    margin: 5px 0;
  }
} 

//PORTFOLIO BUTTON-----PORTFOLIO BUTTON-----PORTFOLIO BUTTON-----PORTFOLIO BUTTON-----PORTFOLIO BUTTON-----PORTFOLIO BUTTON
.buttonWrap{

  #portfolioButton{
    box-shadow: inset 0 0 0 1000px rgba(43, 43, 43, 0.8);
    background: url('../assets/img/portfolio.png') center center no-repeat;
    height: 200px;
    position: fixed;
    width: 100vw;
    // margin-left: -50vw;
    bottom: 0;
    left: 0;
    border: 0;
    box-sizing: border;
    background-size: cover;
    transition:all 0.8s ease-in-out;
    -moz-transition:all 0.8s ease-in-out;
    -webkit-transition:all 0.8s ease-in-out;
    
    &:hover{
      .button{
        color: #fff;
        border: #fff solid 0.2rem;
      }
    }
    .button {
      display: block;
      position: absolute;
      left: 50%;
      top: 30%;
      height: 5rem;
      line-height: 4rem;
      padding-top: 1.3rem;
      width: 15rem;
      text-align: center;
      color: rgba(155, 155, 155, 0.8);
      border: rgba(155, 155, 155, 0.8) solid 0.2rem;
      font-size: 2rem;
      font-weight: bold;
      text-transform: uppercase;
      text-decoration: none;
      transform: translateX(-50%);
      transition: all 0.4s ease-in-out;
      -moz-transition: all 0.4s ease-in-out;
      -webkit-transition: all 0.4s ease-in-out;
      &:hover {
        background-color: rgba(255, 255, 255, 1);
        color: rgba(55, 55, 55, 0.9);  
      }
    }
    &:hover{
      height: 60vh;
      .button{
        top: 40%;
      }
    }
  }
}
</style>
